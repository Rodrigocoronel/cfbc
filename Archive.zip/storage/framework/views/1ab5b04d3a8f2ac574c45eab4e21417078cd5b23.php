<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">

                <div class="panel-heading">Ordenes</div>

                <div class="panel-body">

                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row" style="margin-bottom: 10px;">
                      <div class="col-sm-12 text-right">
                        <button
                         type="button"
                         class="btn btn-sm btn-primary"
                         data-toggle="modal"
                         data-target="#importar_modal">
                          <i class="fa fa-upload" aria-hidden="true"></i>
                          &nbsp;Importar
                        </button>
                      </div>
                    </div>

                    <div>
                      <table id="ordenes_tabla" class="table">
                        <thead>
                          <tr>
                            <th>1</th>
                            <th>2</th>
                            <th>3</th>
                            <th>4</th>
                          </tr>
                        </thead>
                        <tbody></tbody>
                      </table>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>

<div id="importar_modal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Importacion de Ordenes</h4>
      </div>
      <div class="modal-body">
        <p class="text-center">
          <button
           type="button"
           class="btn btn-sm btn-default"
           name="button"
           onClick="document.getElementById('file').click();"
           data-file-upload>
            <i class="fa fa-file-excel-o text-primary" aria-hidden="true"></i>
            &nbsp;Da click para seleccionar el arcivo
          </button>
          <!--  -->
          <button
           type="submit"
           class="btn btn-sm btn-primary"
           name="submit"
           form="importar_form"
           data-file-save>
            <i class="fa fa-upload" aria-hidden="true"></i>
            &nbsp;Da click para importar el archivo
          </button>
          <form id="importar_form" name="importar_form" class="" enctype="multipart/form-data" method="post">
            <input type="file" id="file" name="file" size="10" class="hidden" />
            <p data-file-info class="">
              <b>Nombre: </b><span data-file-name></span><br>
              <b>Tipo: </b><span data-file-type></span><br>
              <b>Tamaño: </b><span data-file-size></span><br>
            </p>
          </form>
        </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrajs'); ?>
<script type="text/javascript">

  $("[data-file-upload]").show();
  $("[data-file-save]").hide();
  $("[data-file-info]").hide();
  $("[data-file-name]").html('');
  $("[data-file-type]").html('');
  $("[data-file-size]").html('');

  var $tabla = $("#ordenes_tabla");

  $(document).ready(function()
  {
    $tabla.DataTable();

    $(':file').on('change', function()
    {
        $("[data-file-upload]").hide();
        $("[data-file-save]").hide();
        $("[data-file-info]").hide();
        $("[data-file-name]").html('');
        $("[data-file-type]").html('');
        $("[data-file-size]").html('');

        var fr    = new FileReader();
        var file  = this.files[0];

        fr.onload = function(evt)
        {
            $("[data-file-save]").show();
            $("[data-file-info]").show();
            $("[data-file-name]").html(file.name);
            $("[data-file-type]").html(file.type);
            $("[data-file-size]").html(file.size);
        };

        fr.readAsDataURL(this.files[0]);
    });

    $('#importar_modal').on('show.bs.modal', function (e)
    {
      $("[data-file-upload]").show();
      $("[data-file-save]").hide();
      $("[data-file-info]").hide();
      $("[data-file-name]").html('');
      $("[data-file-type]").html('');
      $("[data-file-size]").html('');
    });

    $('#importar_form').submit(function(e)
    {
        e.preventDefault();

        $.ajax(
        {
            url: 'app/importar/ordenes',
            method: 'POST',
            data: new FormData(this),
            dataType: 'json',
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function()
            {

            },
            complete: function()
            {

            },
            success: function(response)
            {

            },
            error: function()
            {

            }
        });

    });

  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>