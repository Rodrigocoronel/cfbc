<header class="site-head d-flex align-items-center justify-content-between">
	<div class="wrap mr-4">
		<svg onclick="toggleNav();" fill="currentColor" preserveAspectRatio="xMidYMid meet" height="24" width="24" viewBox="0 0 40 40" style="vertical-align: middle; color: rgb(255, 255, 255); cursor: pointer;"><g><path d="m5 10h30v3.4h-30v-3.4z m0 11.6v-3.2h30v3.2h-30z m0 8.4v-3.4h30v3.4h-30z"></path></g>
		</svg>
	</div>
</header>